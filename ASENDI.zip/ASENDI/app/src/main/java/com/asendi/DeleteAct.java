package com.asendi;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.core.graphics.drawable.DrawableCompat;
import androidx.fragment.app.Fragment;
import org.json.JSONException;

public class DeleteAct extends Fragment {
    private EditText pswd;
    private Button delete;
    private String user,
    pswd_;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
        Bundle savedInstanceState) {
        View layout = inflater.inflate(R.layout.delete_acct, container, false);
        // Inflate the layout for this fragment
        pswd = layout.findViewById(R.id.pswd_);
        delete = layout.findViewById(R.id.dlt_btn);
        Bundle bundle = getArguments();
        assert bundle != null;
        pswd_ = bundle.getString("psd");
        user = bundle.getString("act");
        DrawableCompat.setTint(delete.getBackground(), Color.parseColor("#D32F2F"));
        delete.setOnClickListener(v -> {
            final String pswdt = pswd.getText().toString();
            if (!pswdt.isEmpty()) {
                if (Utils.isConnectionAvailable(requireContext())) {
                    Utils.showNoConnectionAlert(requireContext(), delete);
                } else {
                    if (pswdt.equals(pswd_)) {
                        Utils.connectToServer(getActivity(), GlobalVariables.DLTACC, new String[] {
                            "user", "pswd"
                        }, new String[] {
                            user, pswdt
                        }, true, response -> {
                            try {
                                String auth = response.getString("auth");
                                if (auth.equals("deleted")) {
                                    Toast.makeText(getContext(), requireActivity().getString(R.string.Acc_deleted), Toast.LENGTH_SHORT).show();
                                    try {
                                        GlobalVariables.TIMER.cancel();
                                        GlobalVariables.TIMER.purge();
                                    } catch (Exception ignored) {
                                    }
                                    try {
                                        GlobalVariables.TIMER2.cancel();
                                        GlobalVariables.TIMER2.purge();
                                    } catch (Exception ignored) {
                                    }
                                    Utils.clearAccFromApp(requireContext());
                                    requireActivity().finish();
                                } else if (auth.equals("incorrect")) {
                                    Utils.showMessage(getContext(), delete, requireActivity().getString(R.string.error_pswd), false);
                                } else if (auth.contains("balance")) {
                                    Utils.showMessage(getContext(), delete, requireActivity().getString(R.string.err_bal_dlt), false);
                                } else {
                                    Utils.showMessage(getContext(), delete, requireActivity().getString(R.string.failed), false);
                                }
                            }
                            catch(JSONException je) {
                                Toast.makeText(getContext(), requireActivity().getString(R.string.data_error), Toast.LENGTH_SHORT).show();
                            }
                        });
                    } else {
                        Toast.makeText(getContext(), requireActivity().getString(R.string.error_pswd), Toast.LENGTH_SHORT).show();
                    }
                }} else {
                Toast.makeText(getActivity(), requireActivity().getString(R.string.pswd_required), Toast.LENGTH_SHORT).show();
            }
        });
        return layout;
    }}